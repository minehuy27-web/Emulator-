#!/usr/bin/env bash
# Запускається з кореня репозиторію (де лежить proj/)
set -eux
cd proj
WS="$(cd .. && pwd)"

# --- Android SDK ---
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "build-tools;35.0.1" "platforms;android-35" "cmake;3.10.2.4988404"

# --- Gradle build template ---
T=$(find ~/.local/share/godot/export_templates -name android_source.zip | head -1)
echo "template: $T"
mkdir -p android/build
unzip -q "$T" -d android/build
echo "4.7.2.stable" > android/.build_version
touch android/build/.gdignore
find android/build -maxdepth 3 -not -path '*/res/*' -not -path '*/gradle/*' > /tmp/tree.txt; cat /tmp/tree.txt

G=$(grep -rl "com.android.application" android/build --include='build.gradle*' | head -1)
echo "gradle file: $G"
APP=$(dirname "$G")
echo "APP dir: $APP"

M=$(grep -rl "<application" "$APP" --include=AndroidManifest.xml | head -1)
echo "manifest: $M"
grep -q extractNativeLibs "$M" || sed -i 's/<application/<application android:extractNativeLibs="true"/' "$M"
grep -n extractNativeLibs "$M"

# --- proot з пакетів Termux ---
sudo apt-get install -y patchelf
mkdir -p "$WS/termux" && cd "$WS/termux"
BASE=https://packages.termux.dev/apt/termux-main
curl -fsSL "$BASE/dists/stable/main/binary-aarch64/Packages" -o Packages
for p in proot libtalloc libandroid-shmem; do
  f=$(awk -v p="$p" '$1=="Package:"{cur=$2} $1=="Filename:" && cur==p {print $2; exit}' Packages)
  echo "$p -> $f"
  curl -fsSLO "$BASE/$f"
done
for d in *.deb; do dpkg-deb -x "$d" root; done
U=root/data/data/com.termux/files/usr
cd "$WS/proj"
for V in debug release; do
  J="$APP/libs/$V/arm64-v8a"
  mkdir -p "$J"
  cp "$WS/termux/$U/bin/proot" "$J/libproot.so"
  cp "$WS/termux/$U/libexec/proot/loader" "$J/libproot-loader.so"
  cp -L "$WS/termux/$U/lib/libtalloc.so.2" "$J/libtalloc.so"
  cp -L "$WS/termux/$U/lib/libandroid-shmem.so" "$J/libandroid-shmem.so"
  for f in libproot.so libtalloc.so libandroid-shmem.so; do
    patchelf --set-rpath '$ORIGIN' "$J/$f"
  done
  patchelf --replace-needed libtalloc.so.2 libtalloc.so "$J/libproot.so"
done
readelf -d "$APP/libs/debug/arm64-v8a/libproot.so" | grep -E "NEEDED|RUNPATH|RPATH" || true
ls -l "$APP/libs/debug/arm64-v8a"

# --- Налаштування Godot і ключ ---
if [ -f "$WS/proj/ci/debug.keystore" ]; then
  cp "$WS/proj/ci/debug.keystore" "$HOME/debug.keystore"
else
  keytool -genkey -v -keystore "$HOME/debug.keystore" -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US"
fi
mkdir -p ~/.config/godot
for n in 4 4.7; do
cat > ~/.config/godot/editor_settings-$n.tres << EOT
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$ANDROID_HOME"
export/android/java_sdk_path = "$JAVA_HOME"
EOT
done

# --- Експорт ---
export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="$HOME/debug.keystore"
export GODOT_ANDROID_KEYSTORE_DEBUG_USER=androiddebugkey
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD=android
godot --headless --import || true
mkdir -p out
godot --headless --export-debug "Android" out/launcher.apk
ls -l out
