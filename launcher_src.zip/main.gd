extends Control
## Легкий лаунчер-оболонка: профілі ігор, діагностика, термінал.
## Рендер зупиняється майже повністю, коли гра запущена.

const PROFILES_PATH := "user://profiles.json"
const MENU_FPS := 30
const SLEEP_FPS := 5

var profiles: Array = []
var log_label: RichTextLabel
var game_list: ItemList
var name_edit: LineEdit
var cmd_edit: LineEdit
var term_edit: LineEdit
var url_edit: LineEdit
var env_edit: LineEdit
var linux_edit: LineEdit
var http: HTTPRequest
var worker: Thread

const ROOTFS_URL := "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
const DEFAULT_ENV := "MESA_SHADER_CACHE_DIR=/root/.cache/mesa MESA_SHADER_CACHE_MAX_SIZE=2G"


func _ready() -> void:
	Engine.max_fps = MENU_FPS
	_build_ui()
	_load_profiles()
	_refresh_list()
	_log("Godot %s | GPU: %s" % [Engine.get_version_info().string, RenderingServer.get_video_adapter_name()])


# ---------- UI ----------

func _build_ui() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	add_child(margin)

	var root := VBoxContainer.new()
	margin.add_child(root)

	var tabs := TabContainer.new()
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(tabs)
	tabs.add_child(_build_games_tab())
	tabs.add_child(_build_diag_tab())
	tabs.add_child(_build_term_tab())
	tabs.add_child(_build_linux_tab())

	log_label = RichTextLabel.new()
	log_label.custom_minimum_size = Vector2(0, 180)
	log_label.scroll_following = true
	log_label.selection_enabled = true
	root.add_child(log_label)


func _build_games_tab() -> Control:
	var box := VBoxContainer.new()
	box.name = "Ігри"
	game_list = ItemList.new()
	game_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(game_list)

	name_edit = LineEdit.new()
	name_edit.placeholder_text = "Назва гри"
	box.add_child(name_edit)

	cmd_edit = LineEdit.new()
	cmd_edit.placeholder_text = "Команда запуску (sh -c ...)"
	box.add_child(cmd_edit)

	var row := HBoxContainer.new()
	box.add_child(row)
	row.add_child(_button("Додати", _on_add))
	row.add_child(_button("Видалити", _on_delete))
	row.add_child(_button("Запустити", _on_launch))
	row.add_child(_button("Прокинутись", _on_wake))
	return box


func _build_diag_tab() -> Control:
	var box := VBoxContainer.new()
	box.name = "Діагностика"
	box.add_child(_button("Зібрати діагностику", _on_diag))
	box.add_child(_button("Температура і батарея", _on_thermal))
	return box


func _build_term_tab() -> Control:
	var box := VBoxContainer.new()
	box.name = "Термінал"
	term_edit = LineEdit.new()
	term_edit.placeholder_text = "Команда, наприклад: uname -a"
	term_edit.text_submitted.connect(func(_t: String) -> void: _on_term())
	box.add_child(term_edit)
	box.add_child(_button("Виконати", _on_term))
	return box


func _button(text: String, handler: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 72)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(handler)
	return b


# ---------- Команди ----------

func _shell() -> String:
	return "/system/bin/sh" if OS.get_name() == "Android" else "/bin/sh"


func _run(cmd: String) -> String:
	var output: Array = []
	OS.execute(_shell(), ["-c", cmd], output, true)
	return "".join(output).strip_edges()


func _log(text: String) -> void:
	log_label.append_text(text + "\n")


func _on_diag() -> void:
	_log("[b]Діагностика[/b]")
	_log("uname: " + _run("uname -a"))
	_log("Модель: " + _run("getprop ro.product.model"))
	_log("Android: " + _run("getprop ro.build.version.release"))
	_log("SoC: " + _run("getprop ro.soc.model"))
	_log("Arch: " + _run("uname -m"))
	_log("GPU (Godot): " + RenderingServer.get_video_adapter_name())
	_log("Vulkan/GLES: " + RenderingServer.get_video_adapter_api_version())
	_log("proot: " + _run("command -v proot || echo немає"))


func _on_thermal() -> void:
	var cap := _run("cat /sys/class/power_supply/battery/capacity")
	var temp := _run("cat /sys/class/power_supply/battery/temp")
	_log("Батарея: %s%%, темп (десяті °C): %s" % [cap, temp])
	_log(_run("for z in /sys/class/thermal/thermal_zone*; do echo $(cat $z/type) $(cat $z/temp); done | head -n 12"))


func _on_term() -> void:
	var cmd := term_edit.text.strip_edges()
	if cmd.is_empty():
		return
	_log("$ " + cmd)
	_log(_run(cmd))


# ---------- Профілі ігор ----------

func _on_add() -> void:
	var n := name_edit.text.strip_edges()
	var c := cmd_edit.text.strip_edges()
	if n.is_empty() or c.is_empty():
		_log("Заповни назву і команду")
		return
	profiles.append({"name": n, "command": c})
	_save_profiles()
	_refresh_list()
	name_edit.clear()
	cmd_edit.clear()


func _on_delete() -> void:
	var sel := game_list.get_selected_items()
	if sel.is_empty():
		return
	profiles.remove_at(sel[0])
	_save_profiles()
	_refresh_list()


func _on_launch() -> void:
	var sel := game_list.get_selected_items()
	if sel.is_empty():
		_log("Вибери гру зі списку")
		return
	var p: Dictionary = profiles[sel[0]]
	var pid := OS.create_process(_shell(), ["-c", str(p["command"])])
	_log("Запуск '%s' (pid %d)" % [p["name"], pid])
	Engine.max_fps = SLEEP_FPS  # лаунчер майже не малює, поки йде гра


func _on_wake() -> void:
	Engine.max_fps = MENU_FPS


func _refresh_list() -> void:
	game_list.clear()
	for p in profiles:
		game_list.add_item(str(p["name"]))


func _load_profiles() -> void:
	if not FileAccess.file_exists(PROFILES_PATH):
		return
	var f := FileAccess.open(PROFILES_PATH, FileAccess.READ)
	var data = JSON.parse_string(f.get_as_text())
	if data is Array:
		profiles = data


func _save_profiles() -> void:
	var f := FileAccess.open(PROFILES_PATH, FileAccess.WRITE)
	f.store_string(JSON.stringify(profiles, "\t"))


# ---------- Linux (rootfs + proot) ----------

func _build_linux_tab() -> Control:
	var box := VBoxContainer.new()
	box.name = "Linux"
	url_edit = LineEdit.new()
	url_edit.text = ROOTFS_URL
	box.add_child(url_edit)
	box.add_child(_button("1. Завантажити rootfs", _on_download))
	box.add_child(_button("2. Розпакувати", _on_extract))
	box.add_child(_button("3. Перевірити proot", _on_proot_check))
	env_edit = LineEdit.new()
	env_edit.text = DEFAULT_ENV
	box.add_child(env_edit)
	linux_edit = LineEdit.new()
	linux_edit.text = "uname -a && cat /etc/os-release | head -n 2"
	box.add_child(linux_edit)
	box.add_child(_button("Виконати в Linux", _on_linux_run))
	return box


func _rootfs_dir() -> String:
	return ProjectSettings.globalize_path("user://rootfs")


func _native_dir() -> String:
	# Каталог нативних бібліотек застосунку: там лежить libgodot_android.so,
	# а поруч має лежати libproot.so (exec дозволений лише звідти).
	var f := FileAccess.open("/proc/self/maps", FileAccess.READ)
	if f == null:
		return ""
	while not f.eof_reached():
		var line := f.get_line()
		if line.contains("libgodot_android.so"):
			var parts := line.strip_edges().split(" ", false)
			return parts[parts.size() - 1].get_base_dir()
	return ""


func _q(text: String) -> String:
	return "'" + text.replace("'", "'\\''") + "'"


func _proot_prefix() -> String:
	var d := _native_dir()
	var tmp := ProjectSettings.globalize_path("user://tmp")
	DirAccess.make_dir_recursive_absolute(tmp)
	return "PROOT_TMP_DIR=%s PROOT_LOADER=%s %s -0 --link2symlink -r %s -b /dev -b /proc -b /sys -w /root " % [
		_q(tmp), _q(d + "/libproot-loader.so"), _q(d + "/libproot.so"), _q(_rootfs_dir())]


func _on_download() -> void:
	if http == null:
		http = HTTPRequest.new()
		add_child(http)
		http.request_completed.connect(_on_download_done)
	http.download_file = ProjectSettings.globalize_path("user://rootfs.tar.gz")
	var err := http.request(url_edit.text.strip_edges())
	_log("Завантаження rootfs..." if err == OK else "Помилка запиту: %d" % err)


func _on_download_done(result: int, code: int, _h: PackedStringArray, _b: PackedByteArray) -> void:
	_log("Завантажено: result=%d, HTTP %d" % [result, code])


func _on_extract() -> void:
	if worker != null and worker.is_alive():
		return
	_log("Розпаковую (може тривати хвилину)...")
	worker = Thread.new()
	worker.start(_extract_job)


func _extract_job() -> void:
	var dir := _rootfs_dir()
	var archive := ProjectSettings.globalize_path("user://rootfs.tar.gz")
	var r := _run("mkdir -p %s && tar -xzf %s -C %s 2>&1 | tail -n 5" % [_q(dir), _q(archive), _q(dir)])
	_extract_done.call_deferred(r)


func _extract_done(r: String) -> void:
	worker.wait_to_finish()
	_log("Розпаковано. " + r)


func _on_proot_check() -> void:
	var d := _native_dir()
	_log("Каталог бібліотек: " + d)
	_log("libproot.so: " + _run("ls -l %s 2>&1" % _q(d + "/libproot.so")))
	_log("rootfs: " + _run("ls %s 2>&1 | head -n 8" % _q(_rootfs_dir())))


func _on_linux_run() -> void:
	var inner := linux_edit.text.strip_edges()
	if inner.is_empty():
		return
	var cmd := _proot_prefix() + "/usr/bin/env -i HOME=/root TERM=xterm PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin " \
		+ env_edit.text + " /bin/sh -c " + _q(inner)
	_log("[linux] " + inner)
	_log(_run(cmd))
