Linux Game Launcher (Godot 4.7). Збірка APK робиться через GitHub Actions (build.yml).
Вкладки: Ігри, Діагностика, Термінал, Linux.
